let config = {
  host    : 'ec2-18-216-101-119.us-east-2.compute.amazonaws.com',
  user    : 'rj2yu',
  password: 'MSCI245',
  database: 'rj2yu'
};
 
export default config;
