MyPage functionality:
• The user shall be able to select a movie by title and see recommendations of other movies suggested by the system.
• The system shall recommend movies that have the same genre