#!/bin/sh

npm install
cd client
npm install
cd ..
